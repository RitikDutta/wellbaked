/* Note Codepen is importing the jQuery Background Video plugin - https://github.com/BGStock/jquery-background-video */

$('.jquery-background-video').bgVideo({fadeIn: 2000});