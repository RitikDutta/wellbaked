$(".email-button").click(function(){
  $(".envelope").toggleClass("active");
});

// Blue colors, and that gnarly radial graident came from https://codepen.io/chrisota/pen/qLJtK